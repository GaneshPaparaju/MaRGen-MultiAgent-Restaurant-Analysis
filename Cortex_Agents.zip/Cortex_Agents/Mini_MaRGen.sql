SET user_question = 'Analyze the sales of EL TRIUNFO restaurant';



SELECT $user_question;


WITH query_generator AS (
  SELECT SNOWFLAKE.CORTEX.COMPLETE(
    'claude-3-5-sonnet',
    CONCAT(
      'You are a Snowflake SQL expert. You have two tables: ',
      'HYBRID_YELP_RESTAURANT_SALES(restaurant_id, restaurant_name, city, state, cuisine, yelp_rating, date, is_weekend, revenue, orders, avg_order_value) ',
      'and MENU_SALES_DATA(restaurant_id, restaurant_name, date, item_name, category, unit_price, units_sold, revenue). ',
      'Write a concise aggregated SQL query that answers this question: ',
      $user_question,
      '. Focus on aggregated results (e.g., by date, cuisine, or item), not raw rows. ',
      'Return only the SQL query, no commentary, no markdown.'
    )
  ) AS generated_sql
)
SELECT TRIM(generated_sql) AS GENERATED_SQL
FROM query_generator;



-- Storing the query output as a result
CREATE OR REPLACE TABLE QUERY_RESULTS AS
SELECT 
    h.date,
    h.is_weekend,
    h.yelp_rating,
    h.orders as total_orders,
    h.revenue as total_revenue,
    h.avg_order_value,
    m.category,
    COUNT(DISTINCT m.item_name) as unique_items_sold,
    SUM(m.units_sold) as total_units_sold,
    AVG(m.unit_price) as avg_item_price
FROM HYBRID_YELP_RESTAURANT_SALES h
JOIN MENU_SALES_DATA m ON h.restaurant_id = m.restaurant_id 
    AND h.date = m.date
WHERE h.restaurant_name = 'EL TRIUNFO'
GROUP BY h.date, h.is_weekend, h.yelp_rating, h.orders, h.revenue, 
    h.avg_order_value, m.category
ORDER BY h.date, m.category;


select * from QUERY_RESULTS
limit 5

 -- Generate researcher, writer, and reviewer outputs
WITH
researcher AS (
  SELECT SNOWFLAKE.CORTEX.COMPLETE(
    'claude-3-5-sonnet',
    CONCAT(
      'You are a data-driven research analyst. Here are summarized sales results: ',
      TO_JSON(ARRAY_AGG(OBJECT_CONSTRUCT(*))),
      '. Task: (1) Provide a 3-sentence summary of the findings, ',
      '(2) Suggest 2 hypotheses explaining the patterns, and ',
      '(3) List 2 key metrics to track future performance. ',
      'Format response with headings: SUMMARY:, HYPOTHESES:, METRICS:.'
    )
  ) AS researcher_text
  FROM QUERY_RESULTS
),
writer AS (
  SELECT SNOWFLAKE.CORTEX.COMPLETE(
    'claude-3-5-sonnet',
    CONCAT(
      'You are a business consultant. Based on this analysis: ',
      (SELECT researcher_text FROM researcher),
      '. Write a short professional report including EXECUTIVE_SUMMARY (3–4 sentences), ',
      '3 RECOMMENDATIONS (each 1 sentence). ',
      'Return plain text with section headers.'
    )
  ) AS writer_text
),
reviewer AS (
  SELECT SNOWFLAKE.CORTEX.COMPLETE(
    'claude-3-5-sonnet',
    CONCAT(
      'You are a senior reviewer evaluating this report. Rate clarity (1–10) and structure (1–10). ',
      'Provide one improvement suggestion. Respond with exactly three lines: ',
      '"Clarity: <num>", "Structure: <num>", "Improvement: <sentence>". ',
      'Here is the report:\n', (SELECT writer_text FROM writer)
    )
  ) AS reviewer_text
)
SELECT
  (SELECT researcher_text FROM researcher) AS researcher_output,
  (SELECT writer_text FROM writer) AS writer_output,
  (SELECT reviewer_text FROM reviewer) AS reviewer_output;